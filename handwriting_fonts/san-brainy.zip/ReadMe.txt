Hello,
Thank you for download my font

NOTE:

Be very careful and take the time to read any terms & conditions before deciding to use the font commercially.
Ignorance is not an excuse for breaking the law.

By installing or using this font, you are agree to the Product Usage Agreement:

- Don't re-upload of this font on any web without the permission of the owner. if applicable, a fine!

- This font is already FULL VERSION and ONLY for PERSONAL USE. NO COMMERCIAL USE ALLOWED!

- Commercial License available at:https://rantaustudio.com/

- You will be charged for 100 x Standard License Price if you violate this agreement.

- If you need a CUSTOM LICENSE or CORPORATE LICENSE please contact us at:rantautype(at)gmail.com

- Any donation are very appreciated. Paypal account for donation :
https://www.paypal.me/yudipc

Please visit our store for more amazing fonts :
rantaustudio.com

Follow our instagram for update : https://www.instagram.com/rantautype/
or our behance: https://www.behance.net/rantautype


Thank you.

-------------------

INDONESIA:

Berhati-hatilah dan luangkan waktu untuk membaca Syarat & Ketentuan Lisensi font ini, sebelum memutuskan untuk menggunakan font secara komersial. Ketidaktahuan bukanlah sebuah alasan untuk pelanggaran hukum.
Dengan meng-install font ini, anda dianggap telah membaca, mengerti, dan menyetujui semua Syarat & Ketentuan penggunaan font dibawah ini:

Dengan meng-install font ini, dan membaca persyaratan ini, anda dianggap mengerti dan menyetujui semua syarat dan ketentuan penggunaan font dibawah ini:

- Dilarang mengupload ulang font ini di web manapun tanpa seizin pemilik. jika dikenakan akan dikenakan denda!

- Font demo ini sudah full character yangg hanya dapat digunakan untuk keperluan "Personal Use"/kebutuhan pribadi, atau untuk keperluan yang sifatnya tidak "komersil", alias tidak menghasilkan profit atau keuntungan dari hasil memanfaatkan/menggunakan font kami. Baik itu untuk individu, Agensi Desain Grafis, Percetakan, Distro atau Perusahaan/Korporasi.

- Silakan gunakan lisensi komersial dengan membeli melalui link ini :https://rantaustudio.com/

- Dengan hanya lisensi "Personal Use", DILARANG KERAS menggunakan atau memanfaatkan font ini untuk kepeluan Komersial, baik itu untuk Iklan, Promosi, TV, Film, Video, Motion Graphics, Youtube, Desain kaos distro atau untuk Kemasan Produk (baik Fisik ataupun Digital) atau Media apapun dengan tujuan menghasilkan profit/keuntungan.

- Untuk penggunaan keperluan Perusahaan/Korporasi silakan menggunakan CUSTOM LICENSE.

- Menggunakan font ini dengan lisensi "Personal Use" untuk kepentingan Komersial apapun bentuknya TANPA IZIN dari kami, akan dikenakan biaya EXTENDED LICENSE atau 100x Harga lisensi desktop.

- Saya hanya menerima "lisensi font" sebelum penggunaan

- Saya tidak menerima "lisensi font" setelah penggunaan. (Contoh kasus: anda ketahuan menggunakan font saya untuk keperluan komersil, padahal lisensinya free for personal use, kemudian setelah ketahuan menggunakan font saya, anda membeli lisensinya di link diatas. Nah untuk kejadian yg seperti ini saya tidak akan "MENERIMA LISENSINYA", karena lisensi font yang anda beli adalah "LISENSI SETELAH PENGGUNAAN")

- Anda akan dikenakan biaya 100 kali harga Standard License jika melanggar aturan diatas, atau sesuai dengan ketentuan yang telah diatur dalam Undang-Undang Nomor 28 Tahun 2014 Tentang Hak Cipta yang berlaku di Negara Kesatuan Republik Indonesia.
 
- Lisensi font setelah penggunaan silahkan gunakan sesuai terms & condition yang berlaku setelah anda membeli lisensi font tersebut


Informasi tentang Lisensi apa yang akan anda perlukan, silahkan menghubungi kami di :
Email: rantautype(at)gmail.com

Terima kasih.