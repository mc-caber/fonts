Garfield is a natural signature font, carefully crafted to function like human handwriting. with more than 420 glyphs that can be used for business purposes, branding and logos, signatures, product packaging, titles, body text, invitations, stationary, advertisements, and more.

Feature
-Ligature
-Alternate
-Stylistic
-Multilingual Support
-Uppercase and Lowercase letters
-Numbering and Punctuations


Hope you like my work
Thanks.

Note : This demo font is for PERSONAL USE only! For commercial use and unlock all featured font you can visit our store or contact me via email marunstudio@gmail.com to buy the font.

buy this font : https://fontbundles.net/marunstudio/2177245-garfield-signature
donate for better quality  :  paypal.me/marunstudio
follow my behance for update : behance.net/marunstudio

I hope you like our work
marunstd.
thanks.
